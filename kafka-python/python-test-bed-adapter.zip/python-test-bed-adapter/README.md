# python-test-bed-adapter

## Pre-requisites

## Usage

## Functionality

### Completed

### To be done

# Build

## Dependencies

### Remarks when using the Kafka schema registry

