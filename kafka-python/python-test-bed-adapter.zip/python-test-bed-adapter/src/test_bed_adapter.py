

class KafkaAvroTester :

     def __init__(self):
         print("")